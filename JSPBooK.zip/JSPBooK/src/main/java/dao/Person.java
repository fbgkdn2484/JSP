package dao;

public class Person {
	private int id = 202106042;
	private String name = "홍길동";
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Person() {
		super();
	}
	
	
}
