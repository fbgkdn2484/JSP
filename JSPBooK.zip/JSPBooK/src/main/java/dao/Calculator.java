package dao;

public class Calculator {
	
	public int process(int n) {
		return n*n*n;
	}
	
}
